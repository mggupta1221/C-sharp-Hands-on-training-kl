﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bands
{
    public class StringImplementation1
    {

        //public static void Main(String[] args)
        //{
        //    public string s = " asefdf jka kajskoe ekj ejhd iia ";
        //    string firstName = "Mukesh";
        //    string lastName = "Gupta";

        //    //concatenation
        //    string fullName = firstName + lastName;
        //string Upper=fullName.ToUpper();
        //string lowerr=fullName.ToLower();


        //}

    }
}
