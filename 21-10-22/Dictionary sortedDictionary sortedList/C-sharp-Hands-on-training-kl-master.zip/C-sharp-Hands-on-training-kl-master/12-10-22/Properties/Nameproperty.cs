﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    internal class Nameproperty
    {
        public String ? Name { get; private set; }
    }
}
